<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Agnitus Machine Test</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js" integrity="sha384-LtrjvnR4Twt/qOuYxE721u19sVFLVSA4hf/rRt6PrZTmiPltdZcI7q7PXQBYTKyf" crossorigin="anonymous"></script>
	
    <script type="text/javascript" src="<?php echo base_url();?>material/css-jquery/jquery-3.3.1.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>material/css-jquery/jquery.dataTables.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>material/css-jquery/dataTables.bootstrap4.min.js"></script>
    <script>
	$(document).ready(function () {
	$('#dtBasicExample').DataTable();
	});
	</script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
</head>
<body>

<div class="container">
	<div class="row">
    	<div class="col-md-12">
        	<h1 class="text-center">Country List</h1>
        </div>
    </div>
    <div class="row">
    	<!--<div class="col-md-1">&nbsp;</div>-->
        <div class="col-md-12">
        	<table class="table table-bordered table-striped" id="dtBasicExample">
            	<thead>
                	<tr>
                    	<th width="8%">Sl No</th>
                      <th width="15%">Flag</th>
                        <th width="16%">Name</th>
                        <th width="19%">Capital</th>
                        <th width="16%">Native Name</th>
                        <th width="15%">Region</th>
                        <th width="11%">Action</th>
                    </tr>
                </thead>
                <tbody>
                	<?php if($rows) { $k=1; foreach($rows as $row) {?>
                    <tr>
                    	<td><?php echo $k++; ?></td>
                        <td><img src="<?php echo $row->flag; ?>" class="img-thumbnail" style="width:150px; height:75px;" /></td>
                        <td>
							<span id="name-<?php echo $row->country_id; ?>"><?php echo $row->name; ?></span>
                        	<input type="text" class="form-control" id="name-input-<?php echo $row->country_id; ?>" value="<?php echo $row->name; ?>" style="display:none;">
                            
                            <span id="edit-single-name-<?php echo $row->country_id; ?>" onClick="return single_edit(<?php echo $row->country_id; ?>,'name');"><i class="fa fa-pencil" style="color:#0066FF;"></i></span>
                            <span id="save-single-name-<?php echo $row->country_id; ?>" onClick="return single_save(<?php echo $row->country_id; ?>,'name');" style="display:none;"><i class="fa fa-check" style="color:#098209;"></i></span>
                            &nbsp;&nbsp;&nbsp;
                            <span id="cancel-single-name-<?php echo $row->country_id; ?>" onClick="return single_cancel(<?php echo $row->country_id; ?>,'name');" style="display:none;"><i class="fa fa-times" style="color:#FF0000;"></i></span>
                        </td>
                        <td>
                        	<span id="capital-<?php echo $row->country_id; ?>"><?php echo $row->capital; ?></span>
                        	<input type="text" class="form-control" id="capital-input-<?php echo $row->country_id; ?>" value="<?php echo $row->capital; ?>" style="display:none;">
                            
                            <span id="edit-single-capital-<?php echo $row->country_id; ?>" onClick="return single_edit(<?php echo $row->country_id; ?>,'capital');"><i class="fa fa-pencil" style="color:#0066FF;"></i></span>
                            <span id="save-single-capital-<?php echo $row->country_id; ?>" onClick="return single_save(<?php echo $row->country_id; ?>,'capital');" style="display:none;"><i class="fa fa-check" style="color:#098209;"></i></span>
                            &nbsp;&nbsp;&nbsp;
                            <span id="cancel-single-capital-<?php echo $row->country_id; ?>" onClick="return single_cancel(<?php echo $row->country_id; ?>,'capital');" style="display:none;"><i class="fa fa-times" style="color:#FF0000;"></i></span>
                        </td>
                        <td>
							<span id="native_name-<?php echo $row->country_id; ?>"><?php echo $row->native_name; ?></span>
                        	<input type="text" class="form-control" id="native_name-input-<?php echo $row->country_id; ?>" value="<?php echo $row->native_name; ?>" style="display:none;">
                            
                            <span id="edit-single-native_name-<?php echo $row->country_id; ?>" onClick="return single_edit(<?php echo $row->country_id; ?>,'native_name');"><i class="fa fa-pencil" style="color:#0066FF;"></i></span>
                            <span id="save-single-native_name-<?php echo $row->country_id; ?>" onClick="return single_save(<?php echo $row->country_id; ?>,'native_name');" style="display:none;"><i class="fa fa-check" style="color:#098209;"></i></span>
                            &nbsp;&nbsp;&nbsp;
                            <span id="cancel-single-native_name-<?php echo $row->country_id; ?>" onClick="return single_cancel(<?php echo $row->country_id; ?>,'native_name');" style="display:none;"><i class="fa fa-times" style="color:#FF0000;"></i></span>
                        </td>
                        <td>
                        	<span id="region-<?php echo $row->country_id; ?>"><?php echo $row->region; ?></span>
                        	<input type="text" class="form-control" id="region-input-<?php echo $row->country_id; ?>" value="<?php echo $row->region; ?>" style="display:none;">
                            
                            <span id="edit-single-region-<?php echo $row->country_id; ?>" onClick="return single_edit(<?php echo $row->country_id; ?>,'region');"><i class="fa fa-pencil" style="color:#0066FF;"></i></span>
                            <span id="save-single-region-<?php echo $row->country_id; ?>" onClick="return single_save(<?php echo $row->country_id; ?>,'region');" style="display:none;"><i class="fa fa-check" style="color:#098209;"></i></span>
                            &nbsp;&nbsp;&nbsp;
                            <span id="cancel-single-region-<?php echo $row->country_id; ?>" onClick="return single_cancel(<?php echo $row->country_id; ?>,'region');" style="display:none;"><i class="fa fa-times" style="color:#FF0000;"></i></span>
                        </td>
                        <td>
                        	<a href="javascript:void(0);" class="btn btn-primary btn-sm" id="all-edit-btn-<?php echo $row->country_id; ?>" onClick="return all_edit(<?php echo $row->country_id; ?>);"><i class="fa fa-edit"></i> Edit</a> 
                            <a href="javascript:void(0);" class="btn btn-success btn-sm" id="all-save-btn-<?php echo $row->country_id; ?>" onClick="return all_save(<?php echo $row->country_id; ?>);" style="display:none;"><i class="fa fa-check"></i> Save</a> 
                            <br><br>
                            <a href="javascript:void(0);" class="btn btn-danger btn-sm" id="all-cancel-btn-<?php echo $row->country_id; ?>" onClick="return all_cancel(<?php echo $row->country_id; ?>);" style="display:none;"><i class="fa fa-times"></i> Cancel</a> 
                        </td>
                    </tr>
                    <?php } } ?>
                </tbody>
            </table>
        </div>
        <!--<div class="col-md-1">&nbsp;</div>-->
    </div>
</div>

</body>

<script>
function all_edit(cid) {
	$('#all-edit-btn-'+cid).hide();
	$('#capital-'+cid).hide();
	$('#region-'+cid).hide();
	
	$('#capital-input-'+cid).show();
	$('#region-input-'+cid).show();
	$('#all-save-btn-'+cid).show();
	$('#all-cancel-btn-'+cid).show();
}
function all_cancel(cid) {
	$('#all-edit-btn-'+cid).show();
	$('#capital-'+cid).show();
	$('#region-'+cid).show();
	
	$('#capital-input-'+cid).hide();
	$('#region-input-'+cid).hide();
	$('#all-save-btn-'+cid).hide();
	$('#all-cancel-btn-'+cid).hide();
}
function all_save(cid) {
	var capital=$('#capital-input-'+cid).val();
	var region=$('#region-input-'+cid).val();
	
		$.post({
			url:'<?php echo base_url();?>index.php/welcome/update_all',
			dataType: 'JSON',
			data: { capital:capital,region:region,country_id:cid }
		})
		.done(function(rply) {
			if(rply.status==1) {
				$('#capital-input-'+cid).hide();
				$('#region-input-'+cid).hide();
				$('#all-save-btn-'+cid).hide();
				$('#all-cancel-btn-'+cid).hide();
				$('#all-edit-btn-'+cid).show();
				$('#capital-'+cid).show();
				$('#region-'+cid).show();
				
				$('#capital-'+cid).html(rply.capital);
				$('#region-'+cid).html(rply.region);
				$('#capital-input-'+cid).val(rply.capital);
				$('#region-input-'+cid).val(rply.region);
			} else {
				//	
			}
		})
		.fail(function(rply, txtsts) {
			//
		});
}

function single_edit(cid,fieldName) {
	$('#edit-single-'+fieldName+'-'+cid).hide();
	$('#save-single-'+fieldName+'-'+cid).show();
	$('#cancel-single-'+fieldName+'-'+cid).show();
	
	$('#'+fieldName+'-'+cid).hide();
	$('#'+fieldName+'-input-'+cid).show();
}
function single_cancel(cid,fieldName) {
	$('#edit-single-'+fieldName+'-'+cid).show();
	$('#save-single-'+fieldName+'-'+cid).hide();
	$('#cancel-single-'+fieldName+'-'+cid).hide();
	
	$('#'+fieldName+'-'+cid).show();
	$('#'+fieldName+'-input-'+cid).hide();
}
function single_save(cid,fieldName) {
		var fieldValue=$('#'+fieldName+'-input-'+cid).val();
		
	
		$.post({
			url:'<?php echo base_url();?>index.php/welcome/update_single',
			dataType: 'JSON',
			data: { fieldName:fieldName,fieldValue:fieldValue,country_id:cid }
		})
		.done(function(rply) {
			if(rply.status==1) {
				$('#edit-single-'+rply.fieldName+'-'+cid).show();
				$('#save-single-'+rply.fieldName+'-'+cid).hide();
				$('#cancel-single-'+rply.fieldName+'-'+cid).hide();
	
				$('#'+rply.fieldName+'-'+cid).show();
				$('#'+rply.fieldName+'-input-'+cid).hide();
				
				$('#'+rply.fieldName+'-'+cid).html(rply.fieldValue);
				$('#'+rply.fieldName+'-input-'+cid).val(rply.fieldValue);
			} else {
				//	
			}
		})
		.fail(function(rply, txtsts) {
			//
		});
}
/*$(document).ready(function() {
	
});*/
</script>
</html>