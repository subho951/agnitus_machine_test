<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function index()
	{
		$data['rows']=$this->db->query("select * from tb_countries")->result();
		$this->load->view('welcome_message',$data);
	}
	
	public function update_all()
	{
		$capital=$this->input->post('capital');
		$region=$this->input->post('region');
		$country_id=$this->input->post('country_id');
		$updateCheck = $this->db->query("update tb_countries set capital='$capital',region='$region' where country_id='$country_id'");
		if($updateCheck>0) {
			$return_json = array('status' => 1,'capital'=>$capital,'region'=>$region);
		} else {
			$return_json = array('status' => 0);
		}
		header('Access-Control-Allow-Origin: *');
		echo json_encode($return_json);
	}
	
	public function update_single()
	{
		$fieldName=$this->input->post('fieldName');
		$fieldValue=$this->input->post('fieldValue');
		$country_id=$this->input->post('country_id');
		$updateCheck = $this->db->query("update tb_countries set $fieldName='$fieldValue' where country_id='$country_id'");
		if($updateCheck>0) {
			$return_json = array('status' => 1,'fieldName'=>$fieldName,'fieldValue'=>$fieldValue);
		} else {
			$return_json = array('status' => 0);
		}
		header('Access-Control-Allow-Origin: *');
		echo json_encode($return_json);
	}
}
